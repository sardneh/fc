<?php
// LAST EDIT 7/23/2020 //
date_default_timezone_set('Asia/Jakarta');
require __DIR__ . '/vendor/autoload.php';
define("OS", strtolower(PHP_OS));
header('Content-Type: text/html; charset=utf-8');
error_reporting(0);

//TELEGRAM BOT TOKEN
define('BOT_TOKEN', '1209483560:AAHDjZDJ74DIEzmOEvzKJJXjE8gsxdkpwEw');
 
 function notifTelegram($msg) {
    $API = "https://api.telegram.org/bot".BOT_TOKEN."/sendmessage?chat_id=".CHAT_ID."&text=$msg&parse_mode=markdown";
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'POST');
    curl_setopt($ch, CURLOPT_URL, $API);
    $result = curl_exec($ch);
    curl_close($ch);
    return $result;
}

function idToShortCode($id)
{
  $char_map = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_';
  $base = strlen($char_map);
  $short = '';
  while($id) {
    $id = ($id - ($r = $id % $base)) / $base;
    $short = $char_map{$r} . $short;
  };
  return $short;
}

function waktu($w){
    
    for ($i= $w; $i >= 0; $i--)
    {
        echo "\r";
        echo color()["LR"]."Finding New Post From Target in ".$i." seconds";
        echo "\r";
        echo "                        ";
    }
    echo "\r";
}

function curl($url, $data = 0, $header = 0, $cookie = 0) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
    // curl_setopt($ch, CURLOPT_VERBOSE, 1);
    curl_setopt($ch, CURLOPT_HEADER, 1);
    if($header) {
        curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
        curl_setopt($ch, CURLOPT_ENCODING, "gzip");
    }
    if($data) {
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
    }
    if($cookie) {
        curl_setopt($ch, CURLOPT_COOKIEJAR, $cookie);
        curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie);
    }
    $x = curl_exec($ch);
    curl_close($ch);
    return $x;
}

function curlNoHeader($url, $data = 0, $header = 0, $cookie = 0) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);

    curl_setopt($ch, CURLOPT_HEADER, 0);
    if($header) {
        curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
        curl_setopt($ch, CURLOPT_ENCODING, "gzip");
    }
    if($data) {
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
    }
    if($cookie) {
        curl_setopt($ch, CURLOPT_COOKIEJAR, $cookie);
        curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie);
    }
    $x = curl_exec($ch);
    curl_close($ch);
    return $x;
}

function color() {
    return [
        "LW" => (OS == "linux" ? "\e[1;37m" : ""),
        "WH" => (OS == "linux" ? "\e[0m" : ""),
        "LR" => (OS == "linux" ? "\e[1;31m" : ""),
        "LG" => (OS == "linux" ? "\e[1;32m" : ""),
        "BL" => (OS == "linux" ? "\e[1;34m" : ""),
        "MG" => (OS == "linux" ? "\e[1;35m" : ""),
        "LC" => (OS == "linux" ? "\e[1;36m" : ""),
        "CY" => (OS == "linux" ? "\e[1;33m" : "")
    ];
}

function get_string_between($string, $start, $end){
    $string = ' ' . $string;
    $ini = strpos($string, $start);
    if ($ini == 0) return '';
    $ini += strlen($start);
    $len = strpos($string, $end, $ini) - $ini;
    return substr($string, $ini, $len);
}

function activate_license($license_key, $climate)
{
    $license = 'valid';
    if ($license_key) {
        $url = 'https://toolsig.team/license/?license=' . $license_key;
        try {
            $license_resp = curlNoHeader($url);
        } catch (Exception $e) {
            $msg = $e->getMessage();
            $climate->out($msg);
            run($ig, $climate);
        }
        $license_json = json_decode($license_resp);
        $license = isset($license_json->license) ? $license_json->license : 'invalid';
    } else {
        // License Key not set
        $license_key = null;
    }
    return $license;
}

$debug = false;
$truncatedDebug = false;
$ig = new \InstagramAPI\Instagram($debug, $truncatedDebug);
//$ig = new \InstagramAPI\Instagram();
$climate = new \League\CLImate\CLImate();
$climate->green()->bold("
  ______ _          _               
 |  ____(_)        | |    _     _   
 | |__   _ _ __ ___| |_ _| |_ _| |_ 
 |  __| | | '__/ __| __|_   _|_   _|
 | |    | | |  \__ \ |_  |_|   |_|  
 |_|    |_|_|  |___/\__|            
");
$climate->green()->bold('First Comment Terminal');
$climate->green()->bold('v3.5');
$climate->green('© Developed by @nvzby');
$climate->out('');

    run($ig, $climate);
/**
 * Let's start the show
 */
function run($ig, $climate)
{
    ini_set('memory_limit', '-1');
    ini_set('max_execution_time', '-1');
    try {

        $climate->out('Please provide a valid license key from seller.');
        $climate->out('Example: j5tkjkl4f7e595e9008bb77acc599453');

        $license_key = getVarFromUser("License key");

        if (empty($license_key)) {
            do { 
                $license_key = getVarFromUser("License key");
            } while (empty($license_key));
        }

        $license_key = str_replace(' ', '', $license_key);
        $license_status = activate_license($license_key, $climate);

        if ($license_status == "valid") {
            $climate->backgroundBlueWhite('You license active and valid.');
        } else {
            $climate->backgroundRedWhite('You license key not valid.');
            run($ig, $climate);
        }
                $climate->out('Please provide login data of your Instagram Account.');
                $login = getVarFromUser('Login');
                if (empty($login)) {
                    do {
                        $login = getVarFromUser('Login');
                    } while (empty($login));
                }
                
                //REFRESH SORT KOMEN
                //unlink("./log/$login/sort.log");
                
                $password = getPassword('Password');
                echo PHP_EOL;
                if (empty($password)) {
                    do {
                        echo PHP_EOL;
                        $password = getPassword('Password');
                        echo PHP_EOL;
                    } while (empty($password));
                }
                
                $first_loop = true;
                do {
                    if ($first_loop) {
                        $climate->out("(Optional) Set proxy, if needed. It's better to use a proxy from the same country where you running this script.");
                        $climate->out('Proxy should match following pattern:');
                        $climate->out('http://ip:port or http://username:password@ip:port');
                        $climate->out("Don't use in pattern https://.");
                        $climate->out("Type 3 to skip and don't use proxy.");
                        $first_loop = false;
                    } else {
                        $climate->out('Proxy - [NOT VALID]');
                        $climate->out('Please check the proxy syntax and try again.');
                    }
                    $proxy = getVarFromUser('Proxy');
                    if (empty($proxy)) {
                        do {
                            $proxy = getVarFromUser('Proxy');
                        } while (empty($proxy));
                    }
                    if ('3' === $proxy) {
                        // Skip proxy setup
                        $proxy = '3';
                        break;
                    }
                } while (!isValidProxy($proxy, $climate));
                $proxy_check = isValidProxy($proxy, $climate);
                if ('3' === $proxy) {
                    $proxy = '3';
                    $climate->info('Proxy Setup Skipped');
                } elseif (500 === $proxy_check) {
                    $proxy = '3';
                    $climate->info('Proxy is not valid. Skipping');
                } else {
                    $climate->info('Proxy - [OK]');
                    $ig->setProxy($proxy);
                }
        $login_process = validate_login_process($ig, $login, $password, $climate, $proxy, false);
        $is_connected = $login_process;
        if ($is_connected) {
            $climate->infoBold('Logged as @' . $login . ' successfully.');
        }
        firstComment($ig, $climate, $login);
    } catch (\Exception $e) {
        $climate->errorBold($e->getMessage());
        sleep(1);
        $climate->errorBold('Please run script command again.');
        exit;
    }
}
function validate_login_process($ig, $login, $password, $climate, $proxy, $slient)
{
    $is_connected = false;
    $is_connected_count = 0;
    $fail_message = "There is a problem with your Ethernet connection or Instagram is down at the moment. We couldn't establish connection with Instagram 10 times. Please try again later.";
    do {
        if (10 == $is_connected_count) {
            if ($e->getResponse()) {
                $climate->errorBold($e->getMessage());
            }
            throw new Exception($fail_message);
        }
        try {
            if (0 == $is_connected_count) {
                if ($slient) {
                } else {
                    $climate->infoBold('Emulation of an Instagram app initiated...');
                }
            }
            $login_resp = $ig->login($login, $password);
            if (null !== $login_resp && $login_resp->isTwoFactorRequired()) {
                // Default verification method is phone
                $twofa_method = '1';
                // Detect is Authentification app verification is available
                $is_totp = json_decode(json_encode($login_resp), true);
                if ('1' == $is_totp['two_factor_info']['totp_two_factor_on']) {
                    $climate->infoBold('Two-factor authentication required, please enter the code from you Authentication app');
                    $twofa_id = $login_resp->getTwoFactorInfo()->getTwoFactorIdentifier();
                    $twofa_method = '3';
                } else {
                    $climate->bold(
                        'Two-factor authentication required, please enter the code sent to your number ending in %s',
                        $login_resp->getTwoFactorInfo()->getObfuscatedPhoneNumber()
                    );
                    $twofa_id = $login_resp->getTwoFactorInfo()->getTwoFactorIdentifier();
                }
                $twofa_code = getVarFromUser('Two-factor code');
                if (empty($twofa_code)) {
                    do {
                        $twofa_code = getVarFromUser('Two-factor code');
                    } while (empty($twofa_code));
                }
                $is_connected = false;
                $is_connected_count = 0;
                do {
                    if (10 == $is_connected_count) {
                        if ($e->getResponse()) {
                            $climate->errorBold($e->getMessage());
                        }
                        throw new Exception($fail_message);
                    }
                    if (0 == $is_connected_count) {
                        $climate->infoBold('Two-factor authentication in progress...');
                    }
                    try {
                        $twofa_resp = $ig->finishTwoFactorLogin($login, $password, $twofa_id, $twofa_code, $twofa_method);
                        $is_connected = true;
                    } catch (\InstagramAPI\Exception\NetworkException $e) {
                        sleep(7);
                    } catch (\InstagramAPI\Exception\EmptyResponseException $e) {
                        sleep(7);
                    } catch (\InstagramAPI\Exception\InvalidSmsCodeException $e) {
                        $is_code_correct = false;
                        $is_connected = true;
                        do {
                            $climate->errorBold('Code is incorrect. Please check the syntax and try again.');
                            $twofa_code = getVarFromUser('Two-factor code');
                            if (empty($twofa_code)) {
                                do {
                                    $twofa_code = getVarFromUser('Security code');
                                } while (empty($twofa_code));
                            }
                            $is_connected = false;
                            $is_connected_count = 0;
                            do {
                                try {
                                    if (10 == $is_connected_count) {
                                        if ($e->getResponse()) {
                                            $climte->out($e->getMessage());
                                        }
                                        throw new Exception($fail_message);
                                    }
                                    if (0 == $is_connected_count) {
                                        $climate->infoBold('Verification in progress...');
                                    }
                                    $twofa_resp = $ig->finishTwoFactorLogin($login, $password, $twofa_id, $twofa_code, $twofa_method);
                                    $is_code_correct = true;
                                    $is_connected = true;
                                } catch (\InstagramAPI\Exception\NetworkException $e) {
                                    sleep(7);
                                } catch (\InstagramAPI\Exception\EmptyResponseException $e) {
                                    sleep(7);
                                } catch (\InstagramAPI\Exception\InvalidSmsCodeException $e) {
                                    $is_code_correct = false;
                                    $is_connected = true;
                                } catch (\Exception $e) {
                                    throw $e;
                                }
                                $is_connected_count += 1;
                            } while (!$is_connected);
                        } while (!$is_code_correct);
                    } catch (\Exception $e) {
                        throw $e;
                    }
                    $is_connected_count += 1;
                } while (!$is_connected);
            }
            $is_connected = true;
        } catch (\InstagramAPI\Exception\NetworkException $e) {
            sleep(7);
        } catch (\InstagramAPI\Exception\EmptyResponseException $e) {
            sleep(7);
        } catch (\InstagramAPI\Exception\CheckpointRequiredException $e) {
            throw new Exception('Please go to Instagram website or mobile app and pass checkpoint!');
        } catch (\InstagramAPI\Exception\ChallengeRequiredException $e) {
            if (!($ig instanceof InstagramAPI\Instagram)) {
                throw new Exception('Oops! Something went wrong. Please try again later! (invalid_instagram_client)');
            }
            if (!($e instanceof InstagramAPI\Exception\ChallengeRequiredException)) {
                throw new Exception('Oops! Something went wrong. Please try again later! (unexpected_exception)');
            }
            if (!$e->hasResponse() || !$e->getResponse()->isChallenge()) {
                throw new Exception('Oops! Something went wrong. Please try again later! (unexpected_exception_response)');
            }
            $challenge = $e->getResponse()->getChallenge();
            if (is_array($challenge)) {
                $api_path = $challenge['api_path'];
            } else {
                $api_path = $challenge->getApiPath();
            }
            $climate->info('Instagram want to send you a security code to verify your identity.');
            $climate->info('How do you want receive this code?');
            $climate->infoBold('1 - [Email]');
            $climate->infoBold('2 - [SMS]');
            $climate->infoBold('3 - [Exit]');
            $choice = getVarFromUser('Choice');
            if (empty($choice)) {
                do {
                    $choice = getVarFromUser('Choice');
                } while (empty($choice));
            }
            if ('1' == $choice || '2' == $choice || '3' == $choice) {
                // All fine
            } else {
                $is_choice_ok = false;
                do {
                    $climate->errorBold('Choice is incorrect. Type 1, 2 or 3.');
                    $choice = getVarFromUser('Choice');
                    if (empty($choice)) {
                        do {
                            $choice = getVarFromUser('Choice');
                        } while (empty($choice));
                    }
                    if ('1' == $confirm || '2' == $confirm || '3' == $confirm) {
                        $is_choice_ok = true;
                    }
                } while (!$is_choice_ok);
            }
            $challange_choice = 0;
            if ('3' == $choice) {
                run($ig, $climate);
            } elseif ('1' == $choice) {
                // Email
                $challange_choice = 1;
            } else {
                // SMS
                $challange_choice = 0;
            }
            $is_connected = false;
            $is_connected_count = 0;
            do {
                if (10 == $is_connected_count) {
                    if ($e->getResponse()) {
                        $climate->errorBold($e->getMessage());
                    }
                    throw new Exception($fail_message);
                }
                try {
                    $challenge_resp = $ig->sendChallangeCode($api_path, $challange_choice);
                    // Failed to send challenge code via email. Try with SMS.
                    if ('ok' != $challenge_resp->status) {
                        $challange_choice = 0;
                        sleep(7);
                        $challenge_resp = $ig->sendChallangeCode($api_path, $challange_choice);
                    }
                    $is_connected = true;
                } catch (\InstagramAPI\Exception\NetworkException $e) {
                    sleep(7);
                } catch (\InstagramAPI\Exception\EmptyResponseException $e) {
                    sleep(7);
                } catch (\Exception $e) {
                    throw $e;
                }
                $is_connected_count += 1;
            } while (!$is_connected);
            if ('ok' != $challenge_resp->status) {
                if (isset($challenge_resp->message)) {
                    if ('This field is required.' == $challenge_resp->message) {
                        $climate->info("We received the response 'This field is required.'. This can happen in 2 reasons:");
                        $climate->info('1. Instagram already sent to you verification code to your email or mobile phone number. Please enter this code.');
                        $climate->info('2. Instagram forced you to phone verification challenge. Try login to Instagram app or website and take a look at what happened.');
                    }
                } else {
                    $climate->info('Instagram Response: ' . json_encode($challenge_resp));
                    $climate->info("Couldn't send a verification code for the login challenge. Please try again later.");
                    $climate->info('- Is this account has attached mobile phone number in settings?');
                    $climate->info('- If no, this can be a reason of this problem. You should add mobile phone number in account settings.');
                    throw new Exception('- Sometimes Instagram can force you to phone verification challenge process.');
                }
            }
            if (isset($challenge_resp->step_data->contact_point)) {
                $contact_point = $challenge_resp->step_data->contact_point;
                if (2 == $choice) {
                    $climate->info('Enter the code sent to your number ending in ' . $contact_point . '.');
                } else {
                    $climate->info('Enter the 6-digit code sent to the email address ' . $contact_point . '.');
                }
            }
            $climate->info('If you use 2FA Authentication, Input the same code below!');
            $security_code = getVarFromUser('Security code');
            if (empty($security_code)) {
                do {
                    $security_code = getVarFromUser('Security code');
                } while (empty($security_code));
            }
            if ('3' == $security_code) {
                throw new Exception('Reset in progress...');
            }
            // Verification challenge
            $ig = challange($ig, $login, $password, $api_path, $security_code, $proxy, $climate);
        } catch (\InstagramAPI\Exception\AccountDisabledException $e) {
            throw new Exception('Your account has been disabled for violating Instagram terms. Go Instagram website or mobile app to learn how you may be able to restore your account.');
        } catch (\InstagramAPI\Exception\ConsentRequiredException $e) {
            throw new Exception('Instagram updated Terms and Data Policy. Please go to Instagram website or mobile app to review these changes and accept them.');
        } catch (\InstagramAPI\Exception\SentryBlockException $e) {
            throw new Exception('Access to Instagram API restricted for spam behavior or otherwise abusing. You can try to use Session Catcher script (available by https://nextpost.tech/session-catcher) to get valid Instagram session from location, where your account created from.');
        } catch (\InstagramAPI\Exception\IncorrectPasswordException $e) {
            throw new Exception('The password you entered is incorrect. Please try again.');
        } catch (\InstagramAPI\Exception\InvalidUserException $e) {
            throw new Exception("The username you entered doesn't appear to belong to an account. Please check your username in config file and try again.");
        } catch (\Exception $e) {
            throw $e;
        }
        $is_connected_count += 1;
    } while (!$is_connected);
}
/**
 * Get variable from user
 */
function getVarFromUser($text)
{
    echo $text . ': ';
    $var = trim(fgets(STDIN));
    return $var;
}

function getPassword($prompt) {

    if (OS == 'linux') {
        
        echo $prompt . ': ';

        system('stty -echo');

        $password = trim(fgets(STDIN));

        system('stty echo');

    }else{

        echo $prompt . ': ';
        $password = trim(fgets(STDIN));
    }
    
    return $password;
    
}
/**
 * Validates proxy address
 */
function isValidProxy($proxy, $climate, $slient = false)
{
    if (false === $slient) {
        $climate->info('Connecting to Instagram...');
    }
    $code = null;
    try {
        $client = new \GuzzleHttp\Client();
        $res = $client->request(
            'GET',
            'http://www.instagram.com',
            [
                'timeout' => 60,
                'proxy' => $proxy,
            ]
        );
        $code = $res->getStatusCode();
        $is_connected = true;
    } catch (\Exception $e) {
        //$climate->error( $e->getMessage() );
        $code = '500';
        //return false;
    }
    return $code;
}
/**
 * Validates proxy address
 */
function finishLogin($ig, $login, $password, $proxy, $climate)
{
    $is_connected = false;
    $is_connected_count = 0;
    try {
        do {
            if (10 == $is_connected_count) {
                if ($e->getResponse()) {
                    $climate->out($e->getMessage());
                }
                $fail_message = "There is a problem with your Ethernet connection or Instagram is down at the moment. We couldn't establish connection with Instagram 10 times. Please try again later.";
                $climate->errorBold($fail_message);
                run($ig, $climate);
            }
            if ('3' == $proxy) {
                // Skip proxy setup
            } else {
                $ig->setProxy($proxy);
            }
            try {
                $login_resp = $ig->login($login, $password);
                if (null !== $login_resp && $login_resp->isTwoFactorRequired()) {
                    // Default verification method is phone
                    $twofa_method = '1';
                    // Detect is Authentification app verification is available
                    $is_totp = json_decode(json_encode($login_resp), true);
                    if ('1' == $is_totp['two_factor_info']['totp_two_factor_on']) {
                        $climate->info('Two-factor authentication required, please enter the code from you Authentication app');
                        $twofa_id = $login_resp->getTwoFactorInfo()->getTwoFactorIdentifier();
                        $twofa_method = '3';
                    } else {
                        $climate->info(
                            'Two-factor authentication required, please enter the code sent to your number ending in %s',
                            $login_resp->getTwoFactorInfo()->getObfuscatedPhoneNumber()
                        );
                        $twofa_id = $login_resp->getTwoFactorInfo()->getTwoFactorIdentifier();
                    }
                    $twofa_code = getVarFromUser('Two-factor code');
                    if (empty($twofa_code)) {
                        do {
                            $twofa_code = getVarFromUser('Two-factor code');
                        } while (empty($twofa_code));
                    }
                    $is_connected = false;
                    $is_connected_count = 0;
                    do {
                        if (10 == $is_connected_count) {
                            if ($e->getResponse()) {
                                $climate->errorBold($e->getMessage());
                            }
                            $climate->errorBold($fail_message);
                            run($ig, $climate);
                        }
                        if (0 == $is_connected_count) {
                            $climate->info('Two-factor authentication in progress...');
                        }
                        try {
                            $twofa_resp = $ig->finishTwoFactorLogin($login, $password, $twofa_id, $twofa_code, $twofa_method);
                            $is_connected = true;
                        } catch (\InstagramAPI\Exception\NetworkException $e) {
                            sleep(7);
                        } catch (\InstagramAPI\Exception\EmptyResponseException $e) {
                            sleep(7);
                        } catch (\InstagramAPI\Exception\InvalidSmsCodeException $e) {
                            $is_code_correct = false;
                            $is_connected = true;
                            do {
                                $cliate->errorBold('Code is incorrect. Please check the syntax and try again.');
                                $twofa_code = getVarFromUser('Two-factor code');
                                if (empty($twofa_code)) {
                                    do {
                                        $twofa_code = getVarFromUser('Security code');
                                    } while (empty($twofa_code));
                                }
                                $is_connected = false;
                                $is_connected_count = 0;
                                do {
                                    try {
                                        if (10 == $is_connected_count) {
                                            if ($e->getResponse()) {
                                                $climate->error($e->getMessage());
                                            }
                                            $climate->errorBold($fail_message);
                                            run($ig, $climate);
                                        }
                                        if (0 == $is_connected_count) {
                                            $climate->info('Verification in progress...');
                                        }
                                        $twofa_resp = $ig->finishTwoFactorLogin($login, $password, $twofa_id, $twofa_code, $twofa_method);
                                        $is_code_correct = true;
                                        $is_connected = true;
                                    } catch (\InstagramAPI\Exception\NetworkException $e) {
                                        sleep(7);
                                    } catch (\InstagramAPI\Exception\EmptyResponseException $e) {
                                        sleep(7);
                                    } catch (\InstagramAPI\Exception\InvalidSmsCodeException $e) {
                                        $is_code_correct = false;
                                        $is_connected = true;
                                    } catch (\Exception $e) {
                                        throw new $e();
                                    }
                                    $is_connected_count += 1;
                                } while (!$is_connected);
                            } while (!$is_code_correct);
                        } catch (\Exception $e) {
                            throw $e;
                        }
                        $is_connected_count += 1;
                    } while (!$is_connected);
                }
                $is_connected = true;
            } catch (\InstagramAPI\Exception\NetworkException $e) {
                sleep(7);
            } catch (\InstagramAPI\Exception\EmptyResponseException $e) {
                sleep(7);
            } catch (\InstagramAPI\Exception\CheckpointRequiredException $e) {
                throw new Exception('Please go to Instagram website or mobile app and pass checkpoint!');
            } catch (\InstagramAPI\Exception\ChallengeRequiredException $e) {
                $climate->error('Instagram Response: ' . json_encode($e->getResponse()));
                $climate->error("Couldn't complete the verification challenge. Please try again later.");
                throw new Exception('Developer code: Challenge loop.');
            } catch (\Exception $e) {
                throw $e;
            }
            $is_connected_count += 1;
        } while (!$is_connected);
    } catch (\Exception $e) {
        $climate->errorBold($e->getMessage());
        run($ig, $climate);
    }
    return $ig;
}
/**
 * Verification challenge
 */
function challange($ig, $login, $password, $api_path, $security_code, $proxy, $climate)
{
    $is_connected = false;
    $is_connected_count = 0;
    $fail_message = "There is a problem with your Ethernet connection or Instagram is down at the moment. We couldn't establish connection with Instagram 10 times. Please try again later.";
    do {
        if (10 == $is_connected_count) {
            if ($e->getResponse()) {
                $climate->errorBold($e->getMessage());
            }
            throw new Exception($fail_message);
        }
        if (0 == $is_connected_count) {
            $climate->info('Verification in progress...');
        }
        try {
            $challenge_resp = $ig->finishChallengeLogin($login, $password, $api_path, $security_code);
            $is_connected = true;
        } catch (\InstagramAPI\Exception\NetworkException $e) {
            sleep(7);
        } catch (\InstagramAPI\Exception\EmptyResponseException $e) {
            sleep(7);
        } catch (\InstagramAPI\Exception\InstagramException $e) {
            $msg = $e->getMessage();
            $climate->out($msg);
            $climate->out('Type 3 - to exit.');
            $security_code = getVarFromUser('Security code');
            if (empty($security_code)) {
                do {
                    $security_code = getVarFromUser('Security code');
                } while (empty($security_code));
            }
            if ('3' == $security_code) {
                throw new Exception('Reset in progress...');
            }
        } catch (\Exception $e) {
            $msg = $e->getMessage();
            if ('Invalid Login Response at finishChallengeLogin().' == $msg) {
                sleep(7);
                $ig = finishLogin($ig, $login, $password, $proxy, $climate);
                $is_connected = true;
            } else {
                throw $e;
            }
        }
        $is_connected_count += 1;
    } while (!$is_connected);
    return $ig;
}
/**
 * FirstComment
 */
function firstComment($ig, $climate, $login)
{

        $u = $login;
        
        
        $sleep = getVarFromUser("Sleep in Seconds (Max Speed Input 1 )");
        if (empty($sleep)) {
            do { 
                $sleep = getVarFromUser("Sleep in Seconds (Max Speed Input 1 )");
            } while (empty($sleep));
        }

        $l = getVarFromUser("Limit Comment / Day");
        if (empty($l)) {
            do { 
                $l = getVarFromUser("Limit Comment / Day");
            } while (empty($l));
        }
        
        filecomment:
        $text_comment = getVarFromUser("Enter your file comment here");
        if (empty($text_comment)) {
            do { 
                $text_comment = getVarFromUser("Enter your file comment here");
            } while (empty($text_comment));
        }
        
        if (file_exists($text_comment))  { 
                    //NEXT
        } else { 
        $climate->error("Comment List Not Found!"); 
        goto filecomment;
        
        }

        filetarget:
        $logtarget = getVarFromUser("Enter your file target here");
        if (empty($logtarget)) {
            do { 
                $logtarget = getVarFromUser("Enter your file target here");
            } while (empty($logtarget));
        }
        
        if (file_exists($logtarget))  { 
                    //NEXT
        } else { 
        $climate->error("Target List Not Found!"); 
        goto filetarget;
        
        }
        
        
$optionslike  = [
                'like_on' => 'Enable',
                'like_off' => 'Disable',
            ];
$inputlike    = $climate->radio('Auto Like Post:', $optionslike);
$responselike = $inputlike->prompt();

$optionstele  = [
                'tele_on' => 'Enable',
                'tele_off' => 'Disable',
            ];
$inputtele    = $climate->radio('Telegram Notification:', $optionstele);
$responsetele = $inputtele->prompt();
        
        if ($responsetele == 'tele_on'){
            
                $telegramid = getVarFromUser("Telegram ID");
                if (empty($telegramid)) {
                    do { 
                       $telegramid = getVarFromUser("Telegram ID");
                    } while (empty($telegramid));
                }
        }
        
        define('CHAT_ID',''.$telegramid.'');


$getfile = file_get_contents($text_comment);
$c = count($x) -1;
    
    
    $climate->infoBold('Logged as @' . $u . ' successfully.');
    $climate->out('');    
    $climate->infoBold('First Comment Started');

skip:  
    while (true) {
    try {
    $feed = $ig->timeline->getTimelineFeed();
    $itemsJson = json_decode($feed);
    $items = $itemsJson->feed_items;
        foreach ($items as $item) {
            $mediaFeed = $item->media_or_ad;
            $userinfo = $item->media_or_ad->user;
            $captioninfo = $item->media_or_ad->caption;
            $id       = $mediaFeed->id;
            $username = $userinfo->username;
            $caption = $captioninfo->text;
            
            //GET TIMESTAMP
            $timestamp = $mediaFeed->taken_at;
            $timenow = strtotime("now");
            $timestamp2 = $timestamp + 120;
            $timenow2 = $timenow;
            
            //id to shortcode
            $cut = mb_split('_', $id);
            $shrt = idToShortCode($cut[0]);
            $url = 'https://www.instagram.com/p/'.$shrt.'';
            
            
            if (!file_exists('./log/'.$u.'/')) {
            mkdir('./log/'.$u.'/', 0777, true);
            }
            
            $w = date("d-m-Y");
            $log='./log/'.$u.'/'.$w.'-mediaid.log';
            if(!file_exists( $log )) {
	        fopen($log,'a');
            }
            $alllog='./log/'.$u.'/all-mediaid.log';
            if(!file_exists( $alllog )) {
	        fopen($alllog,'a');
            }
            //$logtarget='target.txt';
            if(!file_exists( $logtarget )) {
	        fopen($logtarget,'a');
            }
            
            
            
            $now = new DateTime();
            $future_date = new DateTime('23:59:59');

            $interval = $future_date->diff($now);
            $seconds = $interval->days*86400 + $interval->h*3600 + $interval->i*60 + $interval->s;
            
            

			$log_data2 = file($log, FILE_IGNORE_NEW_LINES);
			$log_data22 = file($alllog, FILE_IGNORE_NEW_LINES);
            $log_datauser2 = file($logtarget, FILE_IGNORE_NEW_LINES);
            
            //RECHECK FILE LOG MEDIA
            $log_data2x = file($log, FILE_IGNORE_NEW_LINES);
			$log_data22x = file($alllog, FILE_IGNORE_NEW_LINES);
			
			$alllog_data2 = file_get_contents('./log/'.$u.'/all-mediaid.log');
			$linesall = preg_split('/\n|\r/',$alllog_data2);
			$totalkomeng = count($linesall); 
            $totalkomenall = $totalkomeng - 1;
            
            $alllog_data22 = file_get_contents('./log/'.$u.'/'.$w.'-mediaid.log');
			$linesall2 = preg_split('/\n|\r/',$alllog_data22);
			$totalkomen2 = count($linesall2); 
            $totalkomentoday = $totalkomen2;
            
            $limit = $l + 1;
            

            //LIMIT / DAY
			if($totalkomentoday >= $limit) {
            for ($i= $seconds; $i >= 0; $i--)
            {
                echo "\r";
                echo color()["LR"]."".date('H:i:s')." - Limit / Day Has Been Reached. Sleep ".$i." seconds until tomorrow. Total ".$totalkomenall." Post Has Been Commented.";
                sleep(1);
                echo "\r";
                echo "                        ";
            }
                echo "\r";
                } else {

			
            if(in_array($username, $log_datauser2)) {
            //RECHECK 1
            if(in_array($id, $log_data2x) && in_array($id, $log_data22x)) {
               //HAS BEEN COMMENTED
            } else {
            //RECHECK 2
            if(in_array($id, $log_data2) && in_array($id, $log_data22)) {
               //HAS BEEN COMMENTED
            } else {

        if($timenow > $timestamp2){
            
        } else {
            
            //SORT KOMEN
            $komen = file($text_comment);
            $k = count($komen) - 1;

            $sortlog='./log/'.$u.'/sort.log';
            $getsort = file_get_contents($sortlog);
            if(!file_exists( $sortlog )) {
	        fopen($sortlog,'a');
            }
            $num = 0;
            $numplus = $getsort+1;
            
            if($numplus > $k){
            file_put_contents($sortlog, $num);
            $text = $komen[$getsort];
            $text = str_replace("\n", "", $text);
            } else {
            file_put_contents($sortlog, $numplus);
            $text = $komen[$getsort];
            $text = str_replace("\n", "", $text);
            }
            
            $date = date('H:i:s');

                //filter caption by word
    $filterwordfile = "filterpost.txt";
    $fopen = fopen($filterwordfile, "r");
    $fread = fread($fopen,filesize($filterwordfile));
    fclose($fopen);
    $remove = "\n";
    $split = explode($remove, $fread);
    $array[] = null;
    $tab = "\t";
    foreach ($split as $string)
    {
        $row = explode($tab, $string);
        array_push($array,$string);
        if(strpos(strtolower($caption), $string) !== false){
            //echo "Word Found!".PHP_EOL;
                file_put_contents($log, $id . "\n", FILE_APPEND);
                file_put_contents($alllog, $id . "\n", FILE_APPEND);
                echo color()["BL"]."$date ".color()['CY']."- Username: $username | Media ID: $id | Filtered Post by Spesific Keyword!". PHP_EOL;
            
                            
                                    $climate->out("");
                                    $climate->out("Total Post Fetched Today : $totalkomentoday ");
                                    $climate->out("© First Comment Terminal.");
                                    $climate->out("");
                                    goto skip;
            
        }
    }


         
            //COMMENT
            try{
            $resp = $ig->media->comment($id, $text, 1);
            } catch (\InstagramAPI\Exception\NetworkException $e) {
                        //$climate->error("We couldn't connect to Instagram at the moment. Trying again.");
                        $resp = $ig->media->comment($id, $text, 1);
                        continue;
                    } catch (\InstagramAPI\Exception\EmptyResponseException $e) {
                        //$climate->error('Instagram sent us empty response. Trying again.');
                        $resp = $ig->media->comment($id, $text, 1);
                        continue;
                    } catch (\InstagramAPI\Exception\FeedbackRequiredException $e) {
                        $climate->error('This action was blocked. Please try again later. We restrict certain content and actions to protect our community. Tell us if you think we made a mistake. ! Resting during 6 hours before try again.');
                                    $climate->out("");
                                    $climate->out("Total Post Fetched Today : $totalkomentoday ");
                                    $climate->out("© First Comment Terminal.");
                                    $climate->out("");
$notifok = urlencode("*First Comment Log @$u *
Time: $date
Username: *$username*
Status: *This action was blocked. Please try again later. We restrict certain content and actions to protect our community. Tell us if you think we made a mistake. ! Resting during 6 hours before try again.*");    

        if ($responsetele == 'tele_on'){
            notifTelegram($notifok);
        }
                        sleep(6*3600);
                        continue;
                    }
            $response = json_decode($resp);
            
            //CEK LIKE DISABLE OR ENABLE & EXECUTE
            if ($responselike == 'like_on'){
            try{
            $respp = $ig->media->like($id, 1);
            } catch (\InstagramAPI\Exception\NetworkException $e) {
                        //$climate->error("We couldn't connect to Instagram at the moment. Trying again.");
                        $respp = $ig->media->like($id, 1);
                        continue;
                    } catch (\InstagramAPI\Exception\EmptyResponseException $e) {
                        //$climate->error('Instagram sent us empty response. Trying again.');
                        $respp = $ig->media->like($id, 1);
                        continue;
                    } catch (\InstagramAPI\Exception\FeedbackRequiredException $e) {
                                    $climate->error('This action was blocked. Please try again later. We restrict certain content and actions to protect our community. Tell us if you think we made a mistake. ! Resting during 6 hours before try again.');
                                    $climate->out("");
                                    $climate->out("© First Comment Terminal.");
                                    $climate->out("");
                        sleep(6*3600);
                        continue;
                    }
            }
            $responsee = json_decode($respp);
            
            //RESULT
            if ($response->status == 'ok') {
                file_put_contents($log, $id . "\n", FILE_APPEND);
                file_put_contents($alllog, $id . "\n", FILE_APPEND);
                echo color()["BL"]."$date ".color()['LG']."- Username: $username | Media URL: $url | Comment Success: " . color()['MG'].$text." ".PHP_EOL;
                                    $climate->out("");
                                    $climate->out("Total Post Fetched Today : $totalkomentoday ");
                                    $climate->out("© First Comment Terminal.");
                                    $climate->out("");

                                    
$notifok = urlencode("*First Comment Log @$u *
Time: $date
Username: *$username*
Media URL: $url
Comment: *$text*
Status: *OK*");    

        if ($notify == 'y'){
            notifTelegram($notifok);
        } elseif ($notify == 'n') {
            //do nothing
        }

            } elseif ($response->status == 'fail') {
                file_put_contents($log, $id . "\n", FILE_APPEND);
                file_put_contents($alllog, $id . "\n", FILE_APPEND);
                echo color()["BL"]."$date ".color()['LR']."- Username: $username | Media ID: $id | Error Comment Reason: Privated or Blocked or Throttled". PHP_EOL;
            
                            
                                    $climate->out("");
                                    $climate->out("Total Post Fetched Today : $totalkomentoday ");
                                    $climate->out("© First Comment Terminal.");
                                    $climate->out("");
                                }
                         }
                    }
                    
                }
                } else {
                //Not Target
            }
        }
            
                
    } 

                    waktu($sleep);
                    } catch (\InstagramAPI\Exception\NetworkException $e) {
                        //$climate->error("We couldn't connect to Instagram at the moment. Trying again.");
                        sleep(10);
                        continue;
                    } catch (\InstagramAPI\Exception\EmptyResponseException $e) {
                        //$climate->error('Instagram sent us empty response. Trying again.');
                        sleep(10);
                        continue;
                    } catch (\InstagramAPI\Exception\LoginRequiredException $e) {
                        $climate->error('Please login again to your Instagram account. Login required.');
                        run($ig, $climate);
                    } catch (\InstagramAPI\Exception\ChallengeRequiredException $e) {
                        $climate->error('Please login again and pass verification challenge. Instagram will send you a security code to verify your identity.');
                        run($ig, $climate);
                    } catch (\InstagramAPI\Exception\CheckpointRequiredException $e) {
                        $climate->error('Please go to Instagram website or mobile app and pass checkpoint!');
                        run($ig, $climate);
                    } catch (\InstagramAPI\Exception\AccountDisabledException $e) {
                        $climate->error('Your account has been disabled for violating Instagram terms. Go Instagram website or mobile app to learn how you may be able to restore your account.');
                        $climate->error('Use this form for recovery your account: https://help.instagram.com/contact/1652567838289083');
                        run($ig, $climate);
                    } catch (\InstagramAPI\Exception\ConsentRequiredException $e) {
                        $climate->error('Instagram updated Terms and Data Policy. Please go to Instagram website or mobile app to review these changes and accept them.');
                        run($ig, $climate);
                    } catch (\InstagramAPI\Exception\SentryBlockException $e) {
                        $climate->error('Access to Instagram API restricted for spam behavior or otherwise abusing.');
                        run($ig, $climate);
                    } catch (\InstagramAPI\Exception\ThrottledException $e) {
                        $climate->error('Throttled by Instagram because of too many API requests.');
                        sleep(43200);
                    } catch (Exception $e) {
                        //$climate->error($e->getMessage());
                        sleep(7);
                    }
    }
/**
 * Send request
 * @param $url
 * @return mixed
 */
function request($url) {
    $ch = curl_init();

    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

    $return = curl_exec($ch);

    curl_close($ch);

    return $return;
}
}